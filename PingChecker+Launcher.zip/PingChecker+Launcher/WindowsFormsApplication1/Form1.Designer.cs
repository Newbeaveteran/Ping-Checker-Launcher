﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPingCheck = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnOpenLauncher = new System.Windows.Forms.Button();
            this.lbltxtCPing = new System.Windows.Forms.Label();
            this.lblOutputCPing = new System.Windows.Forms.Label();
            this.btnFileLocation = new System.Windows.Forms.Button();
            this.btnIPAddress = new System.Windows.Forms.Button();
            this.lbltxtPingTarget = new System.Windows.Forms.Label();
            this.lbltxtLauncherLocation = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnPingCheck
            // 
            this.btnPingCheck.Location = new System.Drawing.Point(27, 194);
            this.btnPingCheck.Name = "btnPingCheck";
            this.btnPingCheck.Size = new System.Drawing.Size(122, 53);
            this.btnPingCheck.TabIndex = 0;
            this.btnPingCheck.Text = "Ping Check";
            this.btnPingCheck.UseVisualStyleBackColor = true;
            this.btnPingCheck.Click += new System.EventHandler(this.btnPingCheck_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(352, 194);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(134, 53);
            this.btnExit.TabIndex = 1;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnOpenLauncher
            // 
            this.btnOpenLauncher.Location = new System.Drawing.Point(185, 194);
            this.btnOpenLauncher.Name = "btnOpenLauncher";
            this.btnOpenLauncher.Size = new System.Drawing.Size(140, 53);
            this.btnOpenLauncher.TabIndex = 2;
            this.btnOpenLauncher.Text = "Open Launcher";
            this.btnOpenLauncher.UseVisualStyleBackColor = true;
            this.btnOpenLauncher.Click += new System.EventHandler(this.btnOpenLauncher_Click);
            // 
            // lbltxtCPing
            // 
            this.lbltxtCPing.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.lbltxtCPing.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbltxtCPing.Location = new System.Drawing.Point(24, 9);
            this.lbltxtCPing.Name = "lbltxtCPing";
            this.lbltxtCPing.Size = new System.Drawing.Size(67, 26);
            this.lbltxtCPing.TabIndex = 3;
            this.lbltxtCPing.Text = "Current Ping";
            this.lbltxtCPing.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOutputCPing
            // 
            this.lblOutputCPing.BackColor = System.Drawing.Color.White;
            this.lblOutputCPing.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblOutputCPing.Location = new System.Drawing.Point(97, 9);
            this.lblOutputCPing.Name = "lblOutputCPing";
            this.lblOutputCPing.Size = new System.Drawing.Size(119, 26);
            this.lblOutputCPing.TabIndex = 4;
            this.lblOutputCPing.Text = "0 ms";
            this.lblOutputCPing.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblOutputCPing.TextChanged += new System.EventHandler(this.lblOutputCPing_TextChanged);
            // 
            // btnFileLocation
            // 
            this.btnFileLocation.Location = new System.Drawing.Point(352, 151);
            this.btnFileLocation.Name = "btnFileLocation";
            this.btnFileLocation.Size = new System.Drawing.Size(134, 23);
            this.btnFileLocation.TabIndex = 5;
            this.btnFileLocation.Text = "Launcher Location";
            this.btnFileLocation.UseVisualStyleBackColor = true;
            // 
            // btnIPAddress
            // 
            this.btnIPAddress.Location = new System.Drawing.Point(352, 122);
            this.btnIPAddress.Name = "btnIPAddress";
            this.btnIPAddress.Size = new System.Drawing.Size(134, 23);
            this.btnIPAddress.TabIndex = 6;
            this.btnIPAddress.Text = "IP Address";
            this.btnIPAddress.UseVisualStyleBackColor = true;
            // 
            // lbltxtPingTarget
            // 
            this.lbltxtPingTarget.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lbltxtPingTarget.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbltxtPingTarget.Location = new System.Drawing.Point(27, 122);
            this.lbltxtPingTarget.Name = "lbltxtPingTarget";
            this.lbltxtPingTarget.Size = new System.Drawing.Size(64, 23);
            this.lbltxtPingTarget.TabIndex = 7;
            this.lbltxtPingTarget.Text = "Ping Target";
            this.lbltxtPingTarget.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbltxtLauncherLocation
            // 
            this.lbltxtLauncherLocation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lbltxtLauncherLocation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbltxtLauncherLocation.Location = new System.Drawing.Point(27, 151);
            this.lbltxtLauncherLocation.Name = "lbltxtLauncherLocation";
            this.lbltxtLauncherLocation.Size = new System.Drawing.Size(64, 23);
            this.lbltxtLauncherLocation.TabIndex = 8;
            this.lbltxtLauncherLocation.Text = "Launcher";
            this.lbltxtLauncherLocation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Location = new System.Drawing.Point(100, 122);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(246, 23);
            this.label1.TabIndex = 9;
            this.label1.Text = "label1";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label3.Location = new System.Drawing.Point(99, 151);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(247, 23);
            this.label3.TabIndex = 10;
            this.label3.Text = "label3";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(515, 261);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbltxtLauncherLocation);
            this.Controls.Add(this.lbltxtPingTarget);
            this.Controls.Add(this.btnIPAddress);
            this.Controls.Add(this.btnFileLocation);
            this.Controls.Add(this.lblOutputCPing);
            this.Controls.Add(this.lbltxtCPing);
            this.Controls.Add(this.btnOpenLauncher);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnPingCheck);
            this.Name = "Form1";
            this.Text = "Ping Check + Launcher";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnPingCheck;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnOpenLauncher;
        private System.Windows.Forms.Label lbltxtCPing;
        private System.Windows.Forms.Label lblOutputCPing;
        private System.Windows.Forms.Button btnFileLocation;
        private System.Windows.Forms.Button btnIPAddress;
        private System.Windows.Forms.Label lbltxtPingTarget;
        private System.Windows.Forms.Label lbltxtLauncherLocation;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
    }
}

