﻿namespace WindowsFormsApplication1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSaveFLocation = new System.Windows.Forms.Button();
            this.txtFileLocation = new System.Windows.Forms.TextBox();
            this.lblFile = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnSaveFLocation
            // 
            this.btnSaveFLocation.Location = new System.Drawing.Point(482, 38);
            this.btnSaveFLocation.Name = "btnSaveFLocation";
            this.btnSaveFLocation.Size = new System.Drawing.Size(75, 23);
            this.btnSaveFLocation.TabIndex = 0;
            this.btnSaveFLocation.Text = "Save";
            this.btnSaveFLocation.UseVisualStyleBackColor = true;
            this.btnSaveFLocation.Click += new System.EventHandler(this.btnSaveFLocation_Click);
            // 
            // txtFileLocation
            // 
            this.txtFileLocation.Location = new System.Drawing.Point(101, 40);
            this.txtFileLocation.Name = "txtFileLocation";
            this.txtFileLocation.Size = new System.Drawing.Size(375, 20);
            this.txtFileLocation.TabIndex = 1;
            // 
            // lblFile
            // 
            this.lblFile.AutoSize = true;
            this.lblFile.Location = new System.Drawing.Point(25, 43);
            this.lblFile.Name = "lblFile";
            this.lblFile.Size = new System.Drawing.Size(70, 13);
            this.lblFile.TabIndex = 2;
            this.lblFile.Text = "File Location:";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(606, 95);
            this.Controls.Add(this.lblFile);
            this.Controls.Add(this.txtFileLocation);
            this.Controls.Add(this.btnSaveFLocation);
            this.Name = "Form2";
            this.Text = "File Location";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSaveFLocation;
        private System.Windows.Forms.TextBox txtFileLocation;
        private System.Windows.Forms.Label lblFile;
    }
}