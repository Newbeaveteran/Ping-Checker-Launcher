﻿using System;
using System.Drawing;
using System.Net;
using System.Net.NetworkInformation;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{

    public partial class Form1 : Form
    {
        Ping pingSender = new Ping();//For the Ping thing

        bool bolcontPing = false;//This one just determines if you want to continue pinging
        int intCurrentPing = 0;//
        //Dns.GetHostAddresses("www.google.ca")[0];
        //IPAddress strIPAddress = IPAddress.Parse("http://www.google.ca");//default IP Address
        string strLauncherLocation = "F:\\Misc\\Riot games\\lol.launcher.admin.exe";
        public Form1()
        {
            
            InitializeComponent();
           /* while (!bolcontPing)
            {
               // PingReply reply = pingSender.Send(strIPAddress);
                if (reply.Status.Equals(IPStatus.Success))
                {
                    lblOutputCPing.Text = reply.Buffer.Length.ToString()+" ms";
                }
            }*/
        }
        //This is where you exit
        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }
        //Enables and disables the ping
        private void btnPingCheck_Click(object sender, EventArgs e)
        {
            if (!bolcontPing)
            {
                bolcontPing = true;
            }else { bolcontPing = false; }
        }

        private void lblOutputCPing_TextChanged(object sender, EventArgs e)
        {
            if (intCurrentPing < 100)
            {
                lblOutputCPing.BackColor = Color.GreenYellow;
            }else if(intCurrentPing > 100)
            {
                lblOutputCPing.BackColor = Color.Red;
            }
        }

        private void btnOpenLauncher_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(strLauncherLocation);
        }

        private void btnFileLocation_Click(object sender, EventArgs e)
        {
            //Form2.Show();
        }
    }

}
